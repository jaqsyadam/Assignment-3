import java.sql.*;
import java.util.Scanner;

public class Main {
    private static final String db_username = "postgres";
    private static final String db_password = "Altynai2001";
    private static final String db_url = "jdbc:postgresql://localhost:1675/Test";

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        Connection connection = DriverManager.getConnection(db_url, db_username, db_password);
        while (true) {
            System.out.println("1. Показать оценки");
            System.out.println("2. Добавить оценку");
            System.out.println("3. Изменить оценку");
            System.out.println("4. Удалить оценку");
            System.out.println("5. Выйти");

            int command = scanner.nextInt();

            if (command == 1) {
                Statement statement = connection.createStatement();
                ResultSet result = statement.executeQuery("SELECT * FROM GPA ORDER BY ID ASC");
                while(result.next()){
                    System.out.println(result.getInt("ID") + " " + result.getString("COURSE_NAME") + " "
                            + result.getDouble("GRADE"));
                }
            } else if (command == 2) {
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO GPA(COURSE_NAME, GRADE) VALUES (?, ?);");
                System.out.println("Введите название курса: ");
                scanner.nextLine();
                String course = scanner.nextLine();

                if (existsCheck(course)) {
                    System.out.println("Курс с указанным названием существует в таблице.");
                } else {
                    System.out.println("Введите оценку: ");
                    double grade = Double.parseDouble(scanner.next());

                    preparedStatement.setString(1, course);
                    preparedStatement.setDouble(2, grade);
                    preparedStatement.executeUpdate();
                }
            } else if(command == 3){
                PreparedStatement preparedStatement = connection.prepareStatement("UPDATE GPA SET GRADE = ? WHERE COURSE_NAME = ?;");
                System.out.println("Введите название курса:");
                scanner.nextLine();
                String course_name = scanner.nextLine();
                if (existsCheck(course_name)) {
                    preparedStatement.setString(2, course_name);
                    System.out.println("Введите оценку: ");
                    double course_grade = Double.parseDouble(scanner.next());
                    preparedStatement.setDouble(1, course_grade);
                    preparedStatement.executeUpdate();
                } else {
                    System.out.println("Курс с указанным названием не найден в таблице.");
                }
            } else if(command == 4){
                PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM GPA WHERE COURSE_NAME = ?;");
                System.out.println("Введите название курса:");
                scanner.nextLine();
                String courseName = scanner.nextLine();
                if (existsCheck(courseName)) {
                    preparedStatement.setString(1, courseName);
                    preparedStatement.executeUpdate();
                } else {
                    System.out.println("Курс с указанным названием не найден в таблице.");
                }
            } else if (command == 5) {
                System.exit(0);
            } else {
                System.out.println("Неизвестная команда");
            }
        }
    }
    private static boolean existsCheck(String courses_name) throws SQLException {
        Connection connection = DriverManager.getConnection(db_url, db_username, db_password);
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT COUNT(*) FROM GPA WHERE COURSE_NAME = ?;");
        preparedStatement.setString(1, courses_name);
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            return count > 0;
        }
        return false;
    }
}